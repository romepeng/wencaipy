""" 
new_high_history
perids_return; --> rs; oh,ol;ma

close > bull(upper)
            vol > 2*vol(50)
            close > ma(20) hold  to 1w
            oh > 85, ol > 25
            上市时间满1年，历史新高， 申万行业
            一周涨幅；一个月涨幅； 3个月涨幅；一年涨幅； 行业

fields_qeury = ['营业收入(同比增长率)','归属母公司股东的净利润(同比增长率)', '销售毛利率','净资产收益率roe',"所属申万行业"]
fields_qeury = ["一周涨幅,一个月涨幅, 3个月涨幅,六个月涨幅,一年涨幅, 申万行业, 同花顺行业"]

"""