__version__ = '0.1.0'
# -*- coding:utf-8 -*-
import sys
import os
from wencaipy.core.event import (get_scrape_report,
                               set_variable,
                               get_strategy,
                               get_event_evaluate,
                               get_lastjs,
                               search,
                               search_data
                               )


