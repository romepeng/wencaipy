#!/bin/bash

streamlit run /home/romep/wencaipy/wencaipy/stock_streamlitl.py