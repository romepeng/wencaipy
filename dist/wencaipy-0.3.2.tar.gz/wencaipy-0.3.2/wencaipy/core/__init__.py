import pandas as pd

pd.set_option('display.max_columns', 2000)
pd.set_option('display.width', 2000)