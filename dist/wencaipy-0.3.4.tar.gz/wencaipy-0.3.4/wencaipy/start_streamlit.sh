#!/bin/bash

streamlit run ~/wencaipy/wencaipy/stock_streamlit.py
